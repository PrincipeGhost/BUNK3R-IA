# BUNK3R IA - Módulo principal de Inteligencia Artificial
