# BUNK3R_IA API Routes
from .routes import ai_bp
